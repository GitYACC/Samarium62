# Future-Lib

Wrapper library for discord embeds.
---
# [Github](https://github.com/GitYACC/Future-Lib)

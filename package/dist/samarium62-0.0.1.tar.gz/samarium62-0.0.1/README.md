# Future-Lib

Wrapper library for discord embeds.
---
# [Github](github.com/GitYACC/Future-Lib)
